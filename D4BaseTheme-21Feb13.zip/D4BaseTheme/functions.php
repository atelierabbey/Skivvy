<?php // Default functions
include_once 'inc/twtyten.php'; // Twenty Ten functions
include_once 'inc/sidebar_register.php'; // Twenty Ten Sidebar Registry
include_once 'inc/cleanhead.php'; // Stylesheet, Jquery Register, Favicon, and meta data, includes Analytics file footer hook & Custom Log in logo
?>