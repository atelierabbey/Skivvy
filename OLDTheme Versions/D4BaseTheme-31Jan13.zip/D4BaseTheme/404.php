<?php get_header(); ?>

	<h1><?php _e( 'Not Found', 'twentyten' ); ?></h1>

	<p><?php _e( 'Sorry, but the page you requested could not be found. Perhaps searching will help.', 'twentyten' ); ?></p>
	<?php get_search_form(); ?>




<?php get_footer(); ?>