<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>D4 Web Design - Database trouble</title>
</head>
<body style="background: url("/wp-content/themes/reno-web-design/images/bg.jpg") no-repeat scroll center top #FFFFFF;">

<div style="margin:auto; margin-top: 30px; width:500px; background-color:#fff; padding:10px; border: 1px solid #A0B35C;"> 
<div style="background:url("/wp-content/themes/reno-web-design/images/overlay_slider_top.png") no-repeat scroll center top transparent; float:left;"><img src="/images/D4AM-still.png" /></div>
<h1>Database error</h1><br style="clear:both;"/>
Hello, We're sorry but the site is having some trouble at the moment. We are doing our best to bring everything back online,
<br />
Bookmark us and come back later. We apologize for the inconvience.

</div>

</body>
</html>