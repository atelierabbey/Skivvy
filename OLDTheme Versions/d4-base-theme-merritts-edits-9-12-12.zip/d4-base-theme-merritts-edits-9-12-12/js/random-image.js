<!-- Random Image JavaScript
var randnum = Math.random();
var inum = 4;
// Change this number to the number of images you are using.
var rand1 = Math.round(randnum * (inum-1)) + 1;
images = new Array
images[1] = "IMAGE-1-URL"
images[2] = "IMAGE-2-URL"
images[3] = "IMAGE-3-URL"
// Ensure you have an array item for every image you are using.
var image = images[rand1]
// Random Image JavaScript End -->